package com.purplepay.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core Brand Purples
val PhonePePurple = Color(0xFF6739B7)
val PhonePePurpleBright = Color(0xFF7B3FF2)
val PhonePePurpleDeep = Color(0xFF5F259F)
val PhonePePurpleTint = Color(0xFFF2EBFC)
val PhonePePurpleDarkSurface = Color(0xFF231934)

// Dark Theme Palette (Reference: Home, Amount Dark, History)
val DarkBackground = Color(0xFF0E0E10)
val DarkSurface = Color(0xFF1A1A1D)
val DarkSurfaceElevated = Color(0xFF222226)
val DarkBorder = Color(0xFF333338)
val DarkTextPrimary = Color(0xFFF5F5F7)
val DarkTextSecondary = Color(0xFFA0A0A8)
val DarkTextMuted = Color(0xFF707078)
val DarkDisabledButton = Color(0xFF3E3A43)
val DarkDisabledText = Color(0xFF8C8793)

// Light Theme Palette (Reference: Amount Light, Bank Sheet, UPI PIN, Processing)
val LightBackground = Color(0xFFF4F3F8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF8F7FA)
val LightBorder = Color(0xFFE0DFE6)
val LightTextPrimary = Color(0xFF18181B)
val LightTextSecondary = Color(0xFF6E6D76)
val LightTextMuted = Color(0xFF9A99A2)
val LightDisabledButton = Color(0xFFB8B6BE)
val LightDisabledText = Color(0xFF4A4950)

// Status & Accents
val SuccessGreen = Color(0xFF248A3D)
val SuccessGreenBanner = Color(0xFF1E7E34)
val CreditGreen = Color(0xFF2BB656)
val WarningBannerBg = Color(0xFFFFF3CD)
val WarningIconAmber = Color(0xFFF59E0B)
val NpciNavy = Color(0xFF1E3A8A)
val NpciTextDark = Color(0xFF111827)

// Bank Brand Colors
val BobOrange = Color(0xFFF26522)
val CbiRed = Color(0xFFC8102E)
val CbiBlue = Color(0xFF005596)
val SliceBlue = Color(0xFF1D6CE0)
val AvatarGold = Color(0xFFF5B800)
val AvatarBlue = Color(0xFF246BFD)
