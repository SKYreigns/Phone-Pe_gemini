package com.purplepay.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.rounded.NorthEast
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SouthWest
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplepay.app.domain.model.TransactionDirection
import com.purplepay.app.domain.model.TransactionRecord
import com.purplepay.app.ui.components.BottomTab
import com.purplepay.app.ui.components.HelpCircleButton
import com.purplepay.app.ui.components.PhonePeBottomNavigation
import com.purplepay.app.ui.theme.*
import com.purplepay.app.ui.viewmodel.HistoryFilter
import com.purplepay.app.ui.viewmodel.HistoryUiState
import java.text.NumberFormat
import java.util.Locale

@Composable
fun HistoryScreen(
    uiState: HistoryUiState,
    onSearchChanged: (String) -> Unit,
    onFilterChanged: (HistoryFilter) -> Unit,
    onSelectTransaction: (TransactionRecord?) -> Unit,
    onNavigateTab: (BottomTab) -> Unit
) {
    var showFilterMenu by remember { mutableStateOf(false) }
    var showStatementsDialog by remember { mutableStateOf(false) }

    val groupedByMonth = remember(uiState.transactions) {
        uiState.transactions.groupBy { it.monthHeader }
    }

    Scaffold(
        containerColor = DarkBackground,
        bottomBar = {
            PhonePeBottomNavigation(
                currentTab = BottomTab.HISTORY,
                onTabSelected = onNavigateTab
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
                .statusBarsPadding()
        ) {
            // Top Help Icon Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.End
            ) {
                HelpCircleButton(
                    tint = Color.White,
                    onClick = { showStatementsDialog = true }
                )
            }

            // "History" Title + "My Statements" Pill Button (Reference 87156.jpg)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "History",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Transparent,
                    border = BorderStroke(1.dp, Color(0xFF3E3E46)),
                    modifier = Modifier.clickable { showStatementsDialog = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .border(1.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ArrowDownward,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(10.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "My Statements",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Rounded Dark Search Pill with Right Filter Control (Reference 87156.jpg)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(DarkSurface)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search",
                        tint = DarkTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(modifier = Modifier.weight(1f)) {
                        if (uiState.searchQuery.isEmpty()) {
                            Text(
                                text = "Search",
                                color = DarkTextSecondary,
                                fontSize = 15.sp
                            )
                        }
                        BasicTextField(
                            value = uiState.searchQuery,
                            onValueChange = onSearchChanged,
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                            cursorBrush = SolidColor(PhonePePurpleBright),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(22.dp)
                            .background(DarkBorder)
                    )
                    Spacer(modifier = Modifier.width(12.dp))

                    Box {
                        Icon(
                            imageVector = Icons.Rounded.Tune,
                            contentDescription = "Filter",
                            tint = if (uiState.selectedFilter != HistoryFilter.ALL) PhonePePurpleBright else Color.White,
                            modifier = Modifier
                                .size(22.dp)
                                .clickable { showFilterMenu = true }
                        )
                        DropdownMenu(
                            expanded = showFilterMenu,
                            onDismissRequest = { showFilterMenu = false },
                            containerColor = DarkSurfaceElevated
                        ) {
                            HistoryFilter.entries.forEach { filter ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = filter.label,
                                            color = if (uiState.selectedFilter == filter) PhonePePurpleBright else Color.White
                                        )
                                    },
                                    onClick = {
                                        onFilterChanged(filter)
                                        showFilterMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Scrollable Grouped Transaction List
            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                groupedByMonth.forEach { (monthHeader, monthTxns) ->
                    item(key = "header_$monthHeader") {
                        // Month Header Bar: "November 2026" + "+ ₹3,176.81 >"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF161619))
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = monthHeader,
                                color = DarkTextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "+ ₹3,176.81 >",
                                color = CreditGreen,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    items(monthTxns, key = { it.id }) { txn ->
                        TransactionHistoryRow(
                            txn = txn,
                            onClick = { onSelectTransaction(txn) }
                        )
                        HorizontalDivider(
                            thickness = 0.7.dp,
                            color = Color(0xFF1F1F24),
                            modifier = Modifier.padding(start = 68.dp)
                        )
                    }
                }
            }
        }
    }

    // Transaction Receipt Detail Dialog on Row Tap
    if (uiState.selectedTransaction != null) {
        val txn = uiState.selectedTransaction
        AlertDialog(
            onDismissRequest = { onSelectTransaction(null) },
            containerColor = DarkSurfaceElevated,
            title = {
                Text(
                    text = if (txn.direction == TransactionDirection.DEBIT) "Paid to ${txn.payeeName}" else "Received from ${txn.payeeName}",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Amount: ₹${formatAmount(txn.amount)}", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("UPI ID: ${txn.upiId}", color = DarkTextSecondary, fontSize = 13.sp)
                    Text("Transaction ID: ${txn.transactionId}", color = DarkTextSecondary, fontSize = 13.sp)
                    Text("UTR: ${txn.utrNumber}", color = DarkTextSecondary, fontSize = 13.sp)
                    Text("Account: ${txn.bankName} (${txn.maskedAccount})", color = DarkTextSecondary, fontSize = 13.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { onSelectTransaction(null) }) {
                    Text("Close", color = PhonePePurpleBright, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    if (showStatementsDialog) {
        AlertDialog(
            onDismissRequest = { showStatementsDialog = false },
            containerColor = DarkSurfaceElevated,
            title = {
                Text("Download Statement", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Your November 2026 UPI transaction statement (${uiState.transactions.size} entries) is ready.",
                    color = DarkTextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { showStatementsDialog = false }) {
                    Text("OK", color = PhonePePurpleBright, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun TransactionHistoryRow(
    txn: TransactionRecord,
    onClick: () -> Unit
) {
    val isDebit = txn.direction == TransactionDirection.DEBIT
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Circular Dark Direction Arrow Icon (NorthEast for Debit, SouthWest for Credit)
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Color(0xFF232328)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isDebit) Icons.Rounded.NorthEast else Icons.Rounded.SouthWest,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        // Middle: "Paid to" / "Received from", Payee Name, Date Label
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (isDebit) "Paid to" else "Received from",
                color = DarkTextSecondary,
                fontSize = 11.5.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = txn.payeeName,
                color = Color.White,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = txn.displayTimeLabel,
                color = DarkTextSecondary,
                fontSize = 11.5.sp
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Right: Amount + "Debited from / Credited to [Bank Badge]"
        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = if (isDebit) "₹${formatAmount(txn.amount)}" else "+ ₹${formatAmount(txn.amount)}",
                color = if (isDebit) Color.White else CreditGreen,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isDebit) "Debited from" else "Credited to",
                    color = DarkTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.width(5.dp))
                Box(
                    modifier = Modifier
                        .size(15.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(SliceBlue)
                    )
                }
            }
        }
    }
}

private fun formatAmount(amount: Double): String {
    return if (amount % 1.0 == 0.0) {
        NumberFormat.getNumberInstance(Locale("en", "IN")).format(amount.toLong())
    } else {
        String.format(Locale.ENGLISH, "%.2f", amount)
    }
}
