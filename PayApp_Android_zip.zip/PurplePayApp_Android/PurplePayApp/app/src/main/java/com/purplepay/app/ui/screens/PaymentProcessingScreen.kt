package com.purplepay.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplepay.app.ui.theme.PhonePePurple
import com.purplepay.app.ui.theme.PhonePePurpleTint

@Composable
fun PaymentProcessingScreen(
    stageText: String,
    failureMessage: String?,
    onRetry: () -> Unit
) {
    // Prevent accidental back press during active payment processing
    BackHandler(enabled = failureMessage == null) { }

    val infiniteTransition = rememberInfiniteTransition(label = "processingOrbit")
    val orbitProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbitAngle"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp)
    ) {
        if (failureMessage == null) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Soft Lavender Pill + Rotating Purple Arc matching Video 00:10-00:11
                Canvas(modifier = Modifier.size(width = 110.dp, height = 56.dp)) {
                    val pillW = 92.dp.toPx()
                    val pillH = 42.dp.toPx()
                    val left = (size.width - pillW) / 2f
                    val top = (size.height - pillH) / 2f

                    drawRoundRect(
                        color = PhonePePurpleTint,
                        topLeft = Offset(left, top),
                        size = Size(pillW, pillH),
                        cornerRadius = CornerRadius(pillH / 2f, pillH / 2f)
                    )

                    val startAngle = orbitProgress * 360f
                    drawArc(
                        color = PhonePePurple,
                        startAngle = startAngle,
                        sweepAngle = 95f,
                        useCenter = false,
                        topLeft = Offset(left, top),
                        size = Size(pillW, pillH),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                Text(
                    text = stageText,
                    color = Color(0xFF18181B),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            Text(
                text = "please do not press back or close app",
                color = Color(0xFF4B5563),
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 36.dp)
            )
        } else {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Payment Failed",
                    color = Color(0xFFDC2626),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = failureMessage,
                    color = Color(0xFF4B5563),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = PhonePePurple)
                ) {
                    Text("Retry Payment", color = Color.White)
                }
            }
        }
    }
}
