package com.purplepay.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplepay.app.ui.components.BottomTab
import com.purplepay.app.ui.components.PhonePeBottomNavigation
import com.purplepay.app.ui.theme.*

@Composable
fun SearchTabScreen(
    onPayMerchant: (name: String, upiId: String) -> Unit,
    onOpenScanner: () -> Unit,
    onNavigateTab: (BottomTab) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val contacts = listOf(
        Triple("SAROJA CATERERS AND HOSTELS", "EzE0326381@CUB", "SC"),
        Triple("PINTU", "pintu.store@ybl", "PI"),
        Triple("MR ABINASH PRADHAN", "abinash.p@axl", "AP"),
        Triple("Goibibo", "goibibo.payments@hdfcbank", "GO")
    ).filter {
        query.isBlank() || it.first.contains(query, true) || it.second.contains(query, true)
    }

    Scaffold(
        containerColor = DarkBackground,
        bottomBar = {
            PhonePeBottomNavigation(
                currentTab = BottomTab.SEARCH,
                onTabSelected = onNavigateTab
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Text(
                text = "Search Payees & Services",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Enter name, mobile number, or UPI ID", color = DarkTextSecondary) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = DarkTextSecondary) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PhonePePurpleBright,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text("Quick Pay Contacts", color = DarkTextSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(contacts) { (name, upi, initials) ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurface,
                        border = BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPayMerchant(name, upi) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(PhonePePurpleBright),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(initials, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(upi, color = DarkTextSecondary, fontSize = 12.sp)
                            }
                            Icon(
                                imageVector = Icons.Rounded.QrCodeScanner,
                                contentDescription = null,
                                tint = PhonePePurpleBright,
                                modifier = Modifier.clickable { onOpenScanner() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AlertsTabScreen(
    onNavigateTab: (BottomTab) -> Unit
) {
    val alerts = listOf(
        Triple("UPI Payment Debited", "₹80 debited from Bank of Baroda ..1143 towards PINTU.", "1 day ago"),
        Triple("Money Received", "+ ₹60 credited to Bank of Baroda ..1143 from RAVINDRA SINGH S/O RATAN SINGH.", "1 day ago"),
        Triple("Credit Score Updated", "Your November 2026 credit report is available to view for free.", "2 days ago")
    )

    Scaffold(
        containerColor = DarkBackground,
        bottomBar = {
            PhonePeBottomNavigation(
                currentTab = BottomTab.ALERTS,
                onTabSelected = onNavigateTab
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Text(
                text = "Alerts",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(14.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(alerts) { (title, body, time) ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurface,
                        border = BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(PhonePePurpleDarkSurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.NotificationsActive,
                                    contentDescription = null,
                                    tint = PhonePePurpleBright,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(body, color = DarkTextSecondary, fontSize = 12.5.sp, lineHeight = 17.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(time, color = DarkTextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
