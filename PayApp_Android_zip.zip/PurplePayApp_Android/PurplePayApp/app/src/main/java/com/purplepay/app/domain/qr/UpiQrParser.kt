package com.purplepay.app.domain.qr

import android.net.Uri
import com.purplepay.app.domain.model.QrParseResult
import java.net.URLDecoder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UpiQrParser @Inject constructor() {

    fun parse(rawContent: String): QrParseResult {
        val trimmed = rawContent.trim()
        if (trimmed.isBlank()) {
            return QrParseResult.InvalidQr("Empty QR code detected.")
        }

        // Standard UPI deep-link URI: upi://pay?pa=...&pn=...&am=...
        if (trimmed.startsWith("upi://pay", ignoreCase = true) ||
            trimmed.startsWith("upi://", ignoreCase = true)
        ) {
            return try {
                val uri = Uri.parse(trimmed)
                val pa = uri.getQueryParameter("pa")?.trim().orEmpty()
                if (pa.isBlank() || !pa.contains("@")) {
                    return QrParseResult.InvalidQr("Invalid UPI ID in QR code.")
                }
                val rawPn = uri.getQueryParameter("pn")?.trim().orEmpty()
                val decodedPn = if (rawPn.isNotBlank()) {
                    try {
                        URLDecoder.decode(rawPn, "UTF-8")
                    } catch (_: Exception) {
                        rawPn
                    }
                } else {
                    pa.substringBefore("@").uppercase()
                }
                val am = uri.getQueryParameter("am")?.trim()?.takeIf {
                    it.toDoubleOrNull() != null && it.toDouble() > 0.0
                }
                val tn = uri.getQueryParameter("tn")?.trim()?.takeIf { it.isNotBlank() }

                QrParseResult.ValidUpi(
                    payeeName = decodedPn,
                    upiId = pa,
                    presetAmount = am,
                    note = tn
                )
            } catch (_: Exception) {
                QrParseResult.InvalidQr("Malformed UPI QR payload.")
            }
        }

        // Direct VPA string fallback (e.g. merchant@upi)
        val vpaRegex = Regex("^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$")
        if (vpaRegex.matches(trimmed)) {
            return QrParseResult.ValidUpi(
                payeeName = trimmed.substringBefore("@").uppercase(),
                upiId = trimmed
            )
        }

        return QrParseResult.InvalidQr("Unsupported QR format. Scan a valid UPI QR code.")
    }
}
