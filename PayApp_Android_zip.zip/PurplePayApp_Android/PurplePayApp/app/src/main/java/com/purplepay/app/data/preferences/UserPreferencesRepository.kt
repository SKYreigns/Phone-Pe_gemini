package com.purplepay.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "purplepay_prefs")

@Singleton
class UserPreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val SELECTED_BANK_ID = stringPreferencesKey("selected_bank_id")
        val AMOUNT_DARK_MODE = booleanPreferencesKey("amount_dark_mode")
    }

    val selectedBankId: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.SELECTED_BANK_ID] ?: "bob_1143"
    }

    val amountDarkMode: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.AMOUNT_DARK_MODE] ?: false
    }

    suspend fun setSelectedBankId(id: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_BANK_ID] = id
        }
    }

    suspend fun setAmountDarkMode(isDark: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.AMOUNT_DARK_MODE] = isDark
        }
    }
}
