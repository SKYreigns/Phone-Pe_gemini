package com.purplepay.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.purplepay.app.domain.model.TransactionDirection
import com.purplepay.app.domain.model.TransactionRecord
import com.purplepay.app.domain.model.TransactionStatus

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: String,
    val utrNumber: String,
    val payeeName: String,
    val upiId: String,
    val amount: Double,
    val direction: String,
    val status: String,
    val bankName: String,
    val maskedAccount: String,
    val note: String?,
    val timestampMillis: Long,
    val displayTimeLabel: String,
    val monthHeader: String
) {
    fun toDomain(): TransactionRecord = TransactionRecord(
        id = id,
        transactionId = transactionId,
        utrNumber = utrNumber,
        payeeName = payeeName,
        upiId = upiId,
        amount = amount,
        direction = TransactionDirection.valueOf(direction),
        status = TransactionStatus.valueOf(status),
        bankName = bankName,
        maskedAccount = maskedAccount,
        note = note,
        timestampMillis = timestampMillis,
        displayTimeLabel = displayTimeLabel,
        monthHeader = monthHeader
    )

    companion object {
        fun fromDomain(record: TransactionRecord): TransactionEntity = TransactionEntity(
            id = record.id,
            transactionId = record.transactionId,
            utrNumber = record.utrNumber,
            payeeName = record.payeeName,
            upiId = record.upiId,
            amount = record.amount,
            direction = record.direction.name,
            status = record.status.name,
            bankName = record.bankName,
            maskedAccount = record.maskedAccount,
            note = record.note,
            timestampMillis = record.timestampMillis,
            displayTimeLabel = record.displayTimeLabel,
            monthHeader = record.monthHeader
        )
    }
}
