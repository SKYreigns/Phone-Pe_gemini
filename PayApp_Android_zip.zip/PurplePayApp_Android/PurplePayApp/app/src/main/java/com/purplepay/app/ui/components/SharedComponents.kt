package com.purplepay.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplepay.app.domain.model.BankBrandType
import com.purplepay.app.ui.theme.*

enum class BottomTab(val label: String) {
    HOME("Home"),
    SEARCH("Search"),
    SCANNER("Scanner"),
    ALERTS("Alerts"),
    HISTORY("History")
}

@Composable
fun PhonePeBottomNavigation(
    currentTab: BottomTab,
    onTabSelected: (BottomTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF151518),
        modifier = modifier.fillMaxWidth()
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(0.5.dp)
                    .background(Color(0xFF28282E))
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .height(64.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                BottomNavStandardItem(
                    label = "Home",
                    selected = currentTab == BottomTab.HOME,
                    selectedIcon = Icons.Rounded.Home,
                    unselectedIcon = Icons.Outlined.Home,
                    onClick = { onTabSelected(BottomTab.HOME) }
                )
                BottomNavStandardItem(
                    label = "Search",
                    selected = currentTab == BottomTab.SEARCH,
                    selectedIcon = Icons.Rounded.Search,
                    unselectedIcon = Icons.Outlined.Search,
                    onClick = { onTabSelected(BottomTab.SEARCH) }
                )

                // Central Prominent QR Scanner Circle (Reference: 87154.jpg & 87156.jpg)
                val scannerScale by animateFloatAsState(
                    targetValue = if (currentTab == BottomTab.SCANNER) 1.08f else 1.0f,
                    label = "scannerScale"
                )
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .scale(scannerScale)
                        .clip(CircleShape)
                        .background(PhonePePurpleBright)
                        .clickable { onTabSelected(BottomTab.SCANNER) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.QrCodeScanner,
                        contentDescription = "Scan QR",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }

                BottomNavStandardItem(
                    label = "Alerts",
                    selected = currentTab == BottomTab.ALERTS,
                    selectedIcon = Icons.Rounded.Notifications,
                    unselectedIcon = Icons.Outlined.Notifications,
                    onClick = { onTabSelected(BottomTab.ALERTS) }
                )
                BottomNavStandardItem(
                    label = "History",
                    selected = currentTab == BottomTab.HISTORY,
                    selectedIcon = Icons.Rounded.History,
                    unselectedIcon = Icons.Outlined.History,
                    onClick = { onTabSelected(BottomTab.HISTORY) }
                )
            }
        }
    }
}

@Composable
private fun BottomNavStandardItem(
    label: String,
    selected: Boolean,
    selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    val contentColor = if (selected) Color.White else Color(0xFF9E9EA6)
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (selected) selectedIcon else unselectedIcon,
            contentDescription = label,
            tint = contentColor,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            color = contentColor,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
fun HelpCircleButton(
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(28.dp)
            .clip(CircleShape)
            .border(1.5.dp, tint, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "?",
            color = tint,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun BankLogoBadge(
    brandType: BankBrandType,
    size: Dp = 36.dp
) {
    when (brandType) {
        BankBrandType.BANK_OF_BARODA -> {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(8.dp))
                    .background(BobOrange),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(size * 0.72f)) {
                    val w = this.size.width
                    val h = this.size.height
                    for (i in 0..2) {
                        val yOffset = i * (h * 0.25f)
                        drawLine(
                            color = Color.White,
                            start = Offset(w * 0.15f, h * 0.2f + yOffset),
                            end = Offset(w * 0.85f, h * 0.35f + yOffset),
                            strokeWidth = 3.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
        }
        BankBrandType.CENTRAL_BANK_OF_INDIA -> {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(size * 0.8f)) {
                    val c = Offset(this.size.width / 2f, this.size.height / 2f)
                    val r = this.size.minDimension * 0.36f
                    val diamond = Path().apply {
                        moveTo(c.x, c.y - r)
                        lineTo(c.x + r, c.y)
                        lineTo(c.x, c.y + r)
                        lineTo(c.x - r, c.y)
                        close()
                    }
                    drawPath(diamond, color = CbiRed, style = Stroke(width = 4.dp.toPx()))
                    drawCircle(color = CbiBlue, radius = r * 0.32f, center = c)
                }
            }
        }
    }
}

@Composable
fun UpiWordmarkBadge(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "UPI",
            color = Color(0xFF4B4B52),
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            fontStyle = FontStyle.Italic,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.width(2.dp))
        Canvas(modifier = Modifier.size(8.dp, 10.dp)) {
            val p1 = Path().apply {
                moveTo(0f, 0f)
                lineTo(size.width * 0.65f, size.height * 0.5f)
                lineTo(0f, size.height)
                close()
            }
            val p2 = Path().apply {
                moveTo(size.width * 0.35f, 0f)
                lineTo(size.width, size.height * 0.5f)
                lineTo(size.width * 0.35f, size.height)
                close()
            }
            drawPath(p1, Color(0xFFE65100))
            drawPath(p2, Color(0xFF2E7D32))
        }
    }
}

@Composable
fun BhimUpiFooterMark(tint: Color = Color.White.copy(alpha = 0.78f)) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = "BHIM",
            color = tint,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            fontStyle = FontStyle.Italic
        )
        Text(
            text = "  |  ",
            color = tint.copy(alpha = 0.5f),
            fontSize = 14.sp
        )
        Text(
            text = "UPI",
            color = tint,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            fontStyle = FontStyle.Italic
        )
    }
}
