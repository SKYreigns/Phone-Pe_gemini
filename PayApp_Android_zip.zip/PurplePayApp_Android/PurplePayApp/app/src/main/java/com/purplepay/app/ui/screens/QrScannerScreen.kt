package com.purplepay.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.FlashlightOff
import androidx.compose.material.icons.outlined.FlashlightOn
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.purplepay.app.domain.model.QrParseResult
import com.purplepay.app.ui.components.BhimUpiFooterMark
import com.purplepay.app.ui.components.HelpCircleButton
import com.purplepay.app.ui.theme.PhonePePurpleBright
import java.util.concurrent.Executors

@Composable
fun QrScannerScreen(
    onBack: () -> Unit,
    onParseQr: (String) -> QrParseResult,
    onValidQrDetected: (QrParseResult.ValidUpi) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var isTorchOn by remember { mutableStateOf(false) }
    var cameraControl by remember { mutableStateOf<Camera?>(null) }
    var errorBannerMessage by remember { mutableStateOf<String?>(null) }
    var qrConsumed by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Gallery QR Image Upload Picker
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputImage = InputImage.fromFilePath(context, uri)
                val scanner = BarcodeScanning.getClient()
                scanner.process(inputImage)
                    .addOnSuccessListener { barcodes ->
                        val raw = barcodes.firstNotNullOfOrNull { it.rawValue }
                        if (raw != null) {
                            when (val result = onParseQr(raw)) {
                                is QrParseResult.ValidUpi -> {
                                    qrConsumed = true
                                    onValidQrDetected(result)
                                }
                                is QrParseResult.InvalidQr -> {
                                    errorBannerMessage = result.reason
                                }
                            }
                        } else {
                            errorBannerMessage = "No valid QR code found in selected image."
                        }
                    }
                    .addOnFailureListener {
                        errorBannerMessage = "Unable to decode selected QR image."
                    }
            } catch (_: Exception) {
                errorBannerMessage = "Failed to open selected image."
            }
        }
    }

    // Subtle bracket pulse animation
    val infiniteTransition = rememberInfiniteTransition(label = "scannerPulse")
    val bracketAlpha by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bracketAlpha"
    )
    val scanLineProgress by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scanLine"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121215))
    ) {
        // Full-Screen CameraX Preview
        if (hasCameraPermission) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    val executor = Executors.newSingleThreadExecutor()

                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                        val barcodeScanner = BarcodeScanning.getClient()
                        val imageAnalyzer = ImageAnalysis.Builder()
                            .setTargetResolution(Size(1280, 720))
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also { analysis ->
                                analysis.setAnalyzer(executor) { imageProxy ->
                                    val mediaImage = imageProxy.image
                                    if (mediaImage != null && !qrConsumed) {
                                        val inputImage = InputImage.fromMediaImage(
                                            mediaImage,
                                            imageProxy.imageInfo.rotationDegrees
                                        )
                                        barcodeScanner.process(inputImage)
                                            .addOnSuccessListener { barcodes ->
                                                val raw = barcodes.firstOrNull {
                                                    it.format == Barcode.FORMAT_QR_CODE
                                                }?.rawValue
                                                if (raw != null && !qrConsumed) {
                                                    when (val parsed = onParseQr(raw)) {
                                                        is QrParseResult.ValidUpi -> {
                                                            qrConsumed = true
                                                            onValidQrDetected(parsed)
                                                        }
                                                        is QrParseResult.InvalidQr -> {
                                                            errorBannerMessage = parsed.reason
                                                        }
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                                imageProxy.close()
                                            }
                                    } else {
                                        imageProxy.close()
                                    }
                                }
                            }

                        try {
                            cameraProvider.unbindAll()
                            val cam = cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                imageAnalyzer
                            )
                            cameraControl = cam
                        } catch (_: Exception) {
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Permission prompt fallback
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Camera permission is required to scan UPI QR codes.",
                    color = Color.White,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    colors = ButtonDefaults.buttonColors(containerColor = PhonePePurpleBright)
                ) {
                    Text("Grant Camera Permission", color = Color.White)
                }
            }
        }

        // Translucent Dark Scrim + Clear Central Cutout + Four Purple Corner Brackets (Reference 87155.jpg)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cutoutSize = size.width * 0.70f
            val left = (size.width - cutoutSize) / 2f
            val top = size.height * 0.18f
            val right = left + cutoutSize
            val bottom = top + cutoutSize
            val cornerRadius = 24.dp.toPx()

            val cutoutPath = Path().apply {
                addRoundRect(
                    RoundRect(
                        rect = Rect(left, top, right, bottom),
                        cornerRadius = CornerRadius(cornerRadius, cornerRadius)
                    )
                )
            }

            // Outer translucent overlay
            clipPath(cutoutPath, clipOp = ClipOp.Difference) {
                drawRect(color = Color.Black.copy(alpha = 0.42f))
            }

            // Inner slight translucent frost matching reference screenshot
            drawRoundRect(
                color = Color.White.copy(alpha = 0.14f),
                topLeft = Offset(left, top),
                size = androidx.compose.ui.geometry.Size(cutoutSize, cutoutSize),
                cornerRadius = CornerRadius(cornerRadius, cornerRadius)
            )

            // Subtle horizontal scan indicator
            val lineY = top + (cutoutSize * scanLineProgress)
            drawLine(
                color = PhonePePurpleBright.copy(alpha = 0.45f),
                start = Offset(left + 20.dp.toPx(), lineY),
                end = Offset(right - 20.dp.toPx(), lineY),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Four Rounded Purple Scanning Corner Brackets
            val bracketInset = 18.dp.toPx()
            val bLeft = left + bracketInset
            val bTop = top + bracketInset
            val bRight = right - bracketInset
            val bBottom = bottom - bracketInset
            val arm = 26.dp.toPx()
            val arcR = 14.dp.toPx()
            val stroke = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            val bracketColor = PhonePePurpleBright.copy(alpha = bracketAlpha)

            // Top-Left
            drawPath(
                Path().apply {
                    moveTo(bLeft, bTop + arm)
                    lineTo(bLeft, bTop + arcR)
                    quadraticTo(bLeft, bTop, bLeft + arcR, bTop)
                    lineTo(bLeft + arm, bTop)
                },
                color = bracketColor,
                style = stroke
            )
            // Top-Right
            drawPath(
                Path().apply {
                    moveTo(bRight - arm, bTop)
                    lineTo(bRight - arcR, bTop)
                    quadraticTo(bRight, bTop, bRight, bTop + arcR)
                    lineTo(bRight, bTop + arm)
                },
                color = bracketColor,
                style = stroke
            )
            // Bottom-Left
            drawPath(
                Path().apply {
                    moveTo(bLeft, bBottom - arm)
                    lineTo(bLeft, bBottom - arcR)
                    quadraticTo(bLeft, bBottom, bLeft + arcR, bBottom)
                    lineTo(bLeft + arm, bBottom)
                },
                color = bracketColor,
                style = stroke
            )
            // Bottom-Right
            drawPath(
                Path().apply {
                    moveTo(bRight - arm, bBottom)
                    lineTo(bRight - arcR, bBottom)
                    quadraticTo(bRight, bBottom, bRight, bBottom - arcR)
                    lineTo(bRight, bBottom - arm)
                },
                color = bracketColor,
                style = stroke
            )
        }

        // Top Bar: Back Arrow, "Scan any QR" + Subtitle, Help Icon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Scan any QR",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "PhonePe • Google Pay • BHIM • Paytm",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 11.5.sp
                    )
                }
            }

            HelpCircleButton(
                tint = Color.White,
                onClick = {
                    // Quick demo QR trigger when tapping Help or testing without physical QR
                    onValidQrDetected(
                        QrParseResult.ValidUpi(
                            payeeName = "SAROJA CATERERS AND HOSTELS",
                            upiId = "EzE0326381@CUB"
                        )
                    )
                }
            )
        }

        // Upload QR & Torch Controls directly below scanning frame (Reference 87155.jpg)
        Row(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = 118.dp),
            horizontalArrangement = Arrangement.spacedBy(48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ScannerActionCircle(
                label = "Upload QR",
                icon = Icons.Outlined.Image,
                active = false,
                onClick = { galleryLauncher.launch("image/*") }
            )
            ScannerActionCircle(
                label = "Torch",
                icon = if (isTorchOn) Icons.Outlined.FlashlightOn else Icons.Outlined.FlashlightOff,
                active = isTorchOn,
                onClick = {
                    val next = !isTorchOn
                    isTorchOn = next
                    cameraControl?.cameraControl?.enableTorch(next)
                }
            )
        }

        // Invalid QR Feedback Pill if unsupported QR is scanned
        if (errorBannerMessage != null) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF991B1B),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 78.dp, start = 24.dp, end = 24.dp)
                    .clickable { errorBannerMessage = null }
            ) {
                Text(
                    text = errorBannerMessage.orEmpty(),
                    color = Color.White,
                    fontSize = 12.5.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        // Bottom BHIM | UPI Branding
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 22.dp)
        ) {
            BhimUpiFooterMark()
        }
    }
}

@Composable
private fun ScannerActionCircle(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(
                    if (active) PhonePePurpleBright else Color.Black.copy(alpha = 0.45f)
                )
                .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
