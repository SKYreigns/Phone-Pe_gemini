package com.purplepay.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplepay.app.ui.components.BottomTab
import com.purplepay.app.ui.components.HelpCircleButton
import com.purplepay.app.ui.components.PhonePeBottomNavigation
import com.purplepay.app.ui.theme.*

@Composable
fun HomeScreen(
    onOpenScanner: () -> Unit,
    onQuickPayMerchant: (name: String, upiId: String, darkTheme: Boolean) -> Unit,
    onNavigateTab: (BottomTab) -> Unit
) {
    var activeDialogTitle by remember { mutableStateOf<String?>(null) }
    var activeDialogBody by remember { mutableStateOf("") }

    Scaffold(
        containerColor = DarkBackground,
        bottomBar = {
            PhonePeBottomNavigation(
                currentTab = BottomTab.HOME,
                onTabSelected = onNavigateTab
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
                .verticalScroll(rememberScrollState())
        ) {
            // Top Promotional Hero Banner matching Reference 87154.jpg
            HeroWishCreditCardBanner(
                onHelpClick = {
                    activeDialogTitle = "PhonePe Help & Support"
                    activeDialogBody = "24x7 UPI Support, Bank Account Management, and QR Payment Assistance."
                },
                onProfileClick = {
                    activeDialogTitle = "Profile & UPI Settings"
                    activeDialogBody = "Primary Bank: Bank of Baroda (..1143)
Secondary Bank: Central Bank of India (..6325)
UPI ID: suman.kumar@ybl"
                },
                onApplyNowClick = {
                    activeDialogTitle = "WISH RuPay Credit Card"
                    activeDialogBody = "Save 1% on UPI QR Payments with lifetime free virtual RuPay Credit Card."
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Money Transfers Section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Money Transfers",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF33261A),
                    modifier = Modifier.clickable {
                        activeDialogTitle = "Refer & Earn ₹1200"
                        activeDialogBody = "Invite friends to PhonePe UPI and earn ₹200 cashback on their first payment."
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFD97706)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("₹", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Refer → ₹1200",
                            color = Color(0xFFFBBF24),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Four-Column Money Transfer Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PurpleCircularGridItem(
                    label = "To Mobile
Number",
                    icon = Icons.Rounded.PhoneAndroid,
                    onClick = {
                        onQuickPayMerchant("SAROJA CATERERS AND HOSTELS", "EzE0326381@CUB", true)
                    },
                    modifier = Modifier.weight(1f)
                )
                PurpleCircularGridItem(
                    label = "To Bank &
Self A/c",
                    icon = Icons.Rounded.AccountBalance,
                    onClick = {
                        onQuickPayMerchant("SAROJA CATERERS AND HOSTELS", "EzE0326381@CUB", false)
                    },
                    modifier = Modifier.weight(1f)
                )
                PurpleCircularGridItem(
                    label = "PhonePe
Wallet",
                    icon = Icons.Rounded.AccountBalanceWallet,
                    onClick = {
                        activeDialogTitle = "PhonePe Wallet"
                        activeDialogBody = "Active Wallet Balance: ₹450.00
Auto Top-up: Off"
                    },
                    modifier = Modifier.weight(1f)
                )
                PurpleCircularGridItem(
                    label = "Check
Balance",
                    icon = Icons.Rounded.CurrencyRupee,
                    onClick = {
                        activeDialogTitle = "Bank Account Balances"
                        activeDialogBody = "• Bank of Baroda (..1143): ₹42,680.50
• Central Bank of India (..6325): ₹18,420.00"
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Investment & Loan Promo Cards Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurface,
                    border = BorderStroke(1.dp, DarkBorder),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clickable {
                            activeDialogTitle = "PhonePe Invest"
                            activeDialogBody = "Start Daily SIP in Gold, Silver, and Top Mutual Funds from ₹100."
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(PhonePePurpleBright),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("पे", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Explore PhonePe Invest",
                            color = DarkTextPrimary,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 14.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurface,
                    border = BorderStroke(1.dp, DarkBorder),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clickable {
                            activeDialogTitle = "Instant Personal Loan"
                            activeDialogBody = "Pre-approved credit line up to ₹2,00,000 with EMIs starting at ₹2000*."
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFDB2777)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("₹100", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Loan EMIs starting at ₹2000*",
                            color = DarkTextPrimary,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(thickness = 1.dp, color = Color(0xFF1F1F23))
            Spacer(modifier = Modifier.height(14.dp))

            // Recharge & Bills Section
            Text(
                text = "Recharge & Bills",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DarkTileGridItem(
                    label = "Mobile
Recharge",
                    icon = Icons.Rounded.Bolt,
                    iconTint = Color(0xFF60A5FA),
                    onClick = { onQuickPayMerchant("Jio Prepaid Recharge", "jiorecharge@icici", false) },
                    modifier = Modifier.weight(1f)
                )
                DarkTileGridItem(
                    label = "Rent via Credit
Card",
                    icon = Icons.Rounded.HomeWork,
                    iconTint = Color(0xFFF87171),
                    onClick = { onQuickPayMerchant("House Rent UPI", "landlord.rent@okaxis", false) },
                    modifier = Modifier.weight(1f)
                )
                DarkTileGridItem(
                    label = "Electricity
Bill",
                    icon = Icons.Rounded.Lightbulb,
                    iconTint = Color(0xFFFBBF24),
                    onClick = { onQuickPayMerchant("JVVNL Electricity", "jvvnl.bill@hdfcbank", false) },
                    modifier = Modifier.weight(1f)
                )
                DarkTileGridItem(
                    label = "Loan
Repayment",
                    icon = Icons.Rounded.EventAvailable,
                    iconTint = Color(0xFF34D399),
                    onClick = { onQuickPayMerchant("slice small finance bank limited", "slicepay@icici", false) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Additional Promotional Strip: Buy Jio SIM + More ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurface,
                    border = BorderStroke(1.dp, DarkBorder),
                    modifier = Modifier
                        .weight(2.3f)
                        .height(44.dp)
                        .clickable {
                            activeDialogTitle = "Buy Jio SIM: Home Delivered"
                            activeDialogBody = "Free doorstep SIM activation with ₹299 unlimited 5G plan."
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Buy Jio SIM:Home Delivered",
                            color = DarkTextPrimary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Box(
                            modifier = Modifier
                                .size(24.dp, 28.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFDC2626)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SimCard,
                                contentDescription = null,
                                tint = Color(0xFFFDE68A),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurface,
                    border = BorderStroke(1.dp, DarkBorder),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clickable { onOpenScanner() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "More",
                            color = PhonePePurpleBright,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            tint = PhonePePurpleBright,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(thickness = 1.dp, color = Color(0xFF1F1F23))
            Spacer(modifier = Modifier.height(14.dp))

            // Loans Section
            Text(
                text = "Loans",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DarkTileGridItem(
                    label = "Personal
Loan",
                    icon = Icons.Rounded.Person,
                    iconTint = Color(0xFFA78BFA),
                    onClick = {
                        activeDialogTitle = "Personal Loan"
                        activeDialogBody = "Check eligibility in 60 seconds with zero paperwork."
                    },
                    modifier = Modifier.weight(1f)
                )
                DarkTileGridItem(
                    label = "Mutual
Funds Loan",
                    icon = Icons.Rounded.TrendingUp,
                    iconTint = Color(0xFF2DD4BF),
                    onClick = {
                        activeDialogTitle = "Loan Against Mutual Funds"
                        activeDialogBody = "Instant liquidity at 10.5% p.a. without redeeming units."
                    },
                    modifier = Modifier.weight(1f)
                )
                DarkTileGridItem(
                    label = "Gold
Loan",
                    icon = Icons.Rounded.Savings,
                    iconTint = Color(0xFFFBBF24),
                    onClick = {
                        activeDialogTitle = "Gold Loan"
                        activeDialogBody = "Doorstep gold valuation with lowest per-gram interest rates."
                    },
                    modifier = Modifier.weight(1f)
                )
                DarkTileGridItem(
                    label = "Credit
Score",
                    icon = Icons.Rounded.Speed,
                    iconTint = Color(0xFF38BDF8),
                    badgeText = "Latest",
                    onClick = {
                        activeDialogTitle = "Free Credit Score"
                        activeDialogBody = "Your latest Experian Credit Score is 784 (Excellent)."
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (activeDialogTitle != null) {
        AlertDialog(
            onDismissRequest = { activeDialogTitle = null },
            containerColor = DarkSurfaceElevated,
            title = {
                Text(
                    text = activeDialogTitle.orEmpty(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = activeDialogBody,
                    color = DarkTextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { activeDialogTitle = null }) {
                    Text("Close", color = PhonePePurpleBright, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun HeroWishCreditCardBanner(
    onHelpClick: () -> Unit,
    onProfileClick: () -> Unit,
    onApplyNowClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(275.dp)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFD7EFF2), Color(0xFFE7F6F8))
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Top Header Bar: Profile Avatar (left) + Help Circle (right)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clickable(onClick = onProfileClick)
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(AvatarGold),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "S",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .align(Alignment.BottomEnd)
                        .clip(CircleShape)
                        .background(Color(0xFF18181B)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.QrCode,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(9.dp)
                    )
                }
            }

            HelpCircleButton(
                tint = Color(0xFF18181B),
                onClick = onHelpClick
            )
        }

        // Banner Content matching Reference 87154.jpg
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 34.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Denim Pocket + WISH RuPay Credit Card + 1% Sticker
            Box(
                modifier = Modifier
                    .weight(1.05f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.BottomStart
            ) {
                // Denim Pocket Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .height(145.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF6B8BAE), Color(0xFF8CA8C8))
                            )
                        )
                        .border(1.dp, Color(0xFF4F6D8F), RoundedCornerShape(10.dp))
                )

                // Angled Purple WISH Card
                Box(
                    modifier = Modifier
                        .offset(x = 22.dp, y = (-26).dp)
                        .rotate(-22f)
                        .size(width = 102.dp, height = 148.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF5D3FD3), Color(0xFF3A2499))
                            )
                        )
                        .padding(10.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp, 16.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color(0xFFE5E7EB))
                        )
                        Text(
                            text = "WISH",
                            color = Color(0xFFF97316),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "RuPay",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Red/Green 1% Badge
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFE11D48),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = (-6).dp, y = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "1",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF16A34A))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "%",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Right: QR Scan Icon + "Save on QR Payments with WISH Credit Card" + Apply Now >
            Column(
                modifier = Modifier
                    .weight(0.95f)
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.QrCodeScanner,
                    contentDescription = null,
                    tint = Color(0xFF166534),
                    modifier = Modifier.size(44.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Save on
QR Payments",
                    color = Color(0xFF14532D),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "with WISH Credit Card",
                    color = Color(0xFFDC2626),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onApplyNowClick,
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2EA043)),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = "Apply Now >",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Text(
            text = "*T&C Apply",
            color = Color(0xFF64748B),
            fontSize = 8.sp,
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }
}

@Composable
private fun PurpleCircularGridItem(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(PhonePePurpleBright),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = DarkTextPrimary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            lineHeight = 14.sp
        )
    }
}

@Composable
private fun DarkTileGridItem(
    label: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badgeText: String? = null
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(DarkSurface)
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconTint,
                modifier = Modifier.size(24.dp)
            )
            if (badgeText != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = (-2).dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFFFACC15))
                        .padding(horizontal = 4.dp, vertical = 0.5.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = Color.Black,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = DarkTextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            lineHeight = 14.sp
        )
    }
}
