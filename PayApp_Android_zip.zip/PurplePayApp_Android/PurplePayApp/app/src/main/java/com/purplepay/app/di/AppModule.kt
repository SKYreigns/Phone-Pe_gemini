package com.purplepay.app.di

import android.content.Context
import androidx.room.Room
import com.purplepay.app.data.local.PurplePayDatabase
import com.purplepay.app.data.local.TransactionDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): PurplePayDatabase {
        return Room.databaseBuilder(
            context,
            PurplePayDatabase::class.java,
            "purplepay_db"
        ).build()
    }

    @Provides
    fun provideTransactionDao(database: PurplePayDatabase): TransactionDao {
        return database.transactionDao()
    }
}
