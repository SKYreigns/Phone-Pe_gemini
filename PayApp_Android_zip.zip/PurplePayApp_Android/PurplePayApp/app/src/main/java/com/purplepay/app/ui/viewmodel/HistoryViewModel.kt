package com.purplepay.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.purplepay.app.data.repository.PaymentRepository
import com.purplepay.app.domain.model.TransactionDirection
import com.purplepay.app.domain.model.TransactionRecord
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

enum class HistoryFilter(val label: String) {
    ALL("All"),
    DEBIT("Paid"),
    CREDIT("Received")
}

data class HistoryUiState(
    val searchQuery: String = "",
    val selectedFilter: HistoryFilter = HistoryFilter.ALL,
    val transactions: List<TransactionRecord> = emptyList(),
    val selectedTransaction: TransactionRecord? = null
)

@HiltViewModel
class HistoryViewModel @Inject constructor(
    paymentRepository: PaymentRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _selectedFilter = MutableStateFlow(HistoryFilter.ALL)
    private val _selectedTransaction = MutableStateFlow<TransactionRecord?>(null)

    val uiState: StateFlow<HistoryUiState> = combine(
        paymentRepository.observeTransactions(),
        _searchQuery,
        _selectedFilter,
        _selectedTransaction
    ) { allTxns, query, filter, selected ->
        val filtered = allTxns.filter { txn ->
            val matchesQuery = query.isBlank() ||
                txn.payeeName.contains(query, ignoreCase = true) ||
                txn.upiId.contains(query, ignoreCase = true) ||
                txn.amount.toString().contains(query)
            val matchesFilter = when (filter) {
                HistoryFilter.ALL -> true
                HistoryFilter.DEBIT -> txn.direction == TransactionDirection.DEBIT
                HistoryFilter.CREDIT -> txn.direction == TransactionDirection.CREDIT
            }
            matchesQuery && matchesFilter
        }
        HistoryUiState(
            searchQuery = query,
            selectedFilter = filter,
            transactions = filtered,
            selectedTransaction = selected
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HistoryUiState()
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onFilterChanged(filter: HistoryFilter) {
        _selectedFilter.value = filter
    }

    fun openTransactionDetails(record: TransactionRecord?) {
        _selectedTransaction.value = record
    }
}
