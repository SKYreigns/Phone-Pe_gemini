package com.purplepay.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.purplepay.app.data.preferences.UserPreferencesRepository
import com.purplepay.app.data.repository.PaymentRepository
import com.purplepay.app.domain.model.BankAccount
import com.purplepay.app.domain.model.PayeeInfo
import com.purplepay.app.domain.model.QrParseResult
import com.purplepay.app.domain.model.TransactionRecord
import com.purplepay.app.domain.qr.UpiQrParser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

data class PaymentFlowUiState(
    val payee: PayeeInfo = PayeeInfo(
        name = "SAROJA CATERERS AND HOSTELS",
        upiId = "EzE0326381@CUB",
        initials = "SC",
        isDarkThemeEntry = false
    ),
    val amountInput: String = "",
    val noteInput: String = "",
    val isDarkAmountTheme: Boolean = false,
    val showBankSheet: Boolean = false,
    val bankAccounts: List<BankAccount> = emptyList(),
    val selectedBankId: String = "bob_1143",
    val pinDigits: String = "",
    val pinError: String? = null,
    val processingStage: String = "Connecting Securely",
    val isProcessing: Boolean = false,
    val paymentFailedMessage: String? = null,
    val completedRecord: TransactionRecord? = null,
    val formattedSuccessTimestamp: String = ""
) {
    val parsedAmount: Double
        get() = amountInput.toDoubleOrNull() ?: 0.0

    val isAmountValid: Boolean
        get() = parsedAmount > 0.0 && parsedAmount <= 100000.0

    val formattedAmountDisplay: String
        get() {
            if (amountInput.isBlank()) return "0"
            val d = parsedAmount
            return if (d % 1.0 == 0.0 && !amountInput.contains(".")) {
                d.toLong().toString()
            } else {
                amountInput
            }
        }

    val selectedBank: BankAccount
        get() = bankAccounts.find { it.id == selectedBankId }
            ?: bankAccounts.firstOrNull()
            ?: BankAccount(
                id = "bob_1143",
                bankName = "Bank of Baroda",
                maskedNumber = "..1143",
                fullAccountNumber = "XXXX1143",
                isRecommended = true,
                brandType = com.purplepay.app.domain.model.BankBrandType.BANK_OF_BARODA
            )
}

@HiltViewModel
class PaymentFlowViewModel @Inject constructor(
    private val paymentRepository: PaymentRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val qrParser: UpiQrParser
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        PaymentFlowUiState(bankAccounts = paymentRepository.getBankAccounts())
    )
    val uiState: StateFlow<PaymentFlowUiState> = _uiState.asStateFlow()

    private var paymentJob: Job? = null

    init {
        viewModelScope.launch {
            val savedBank = preferencesRepository.selectedBankId.first()
            _uiState.update { it.copy(selectedBankId = savedBank) }
        }
    }

    fun startPaymentSession(
        payeeName: String,
        upiId: String,
        presetAmount: String? = null,
        note: String? = null,
        darkAmountTheme: Boolean = false
    ) {
        paymentJob?.cancel()
        val initials = computeInitials(payeeName)
        _uiState.update {
            it.copy(
                payee = PayeeInfo(
                    name = payeeName,
                    upiId = upiId,
                    initials = initials,
                    isDarkThemeEntry = darkAmountTheme
                ),
                amountInput = presetAmount.orEmpty(),
                noteInput = note.orEmpty(),
                isDarkAmountTheme = darkAmountTheme,
                showBankSheet = false,
                pinDigits = "",
                pinError = null,
                isProcessing = false,
                paymentFailedMessage = null,
                completedRecord = null
            )
        }
    }

    fun parseQrString(raw: String): QrParseResult = qrParser.parse(raw)

    fun toggleAmountTheme() {
        _uiState.update { it.copy(isDarkAmountTheme = !it.isDarkAmountTheme) }
    }

    fun onAmountChanged(raw: String) {
        val cleaned = raw.filter { it.isDigit() || it == '.' }
        val parts = cleaned.split(".")
        val valid = when {
            parts.size > 2 -> "${parts[0]}.${parts[1].take(2)}"
            parts.size == 2 -> "${parts[0].take(6)}.${parts[1].take(2)}"
            else -> cleaned.take(6)
        }
        _uiState.update { it.copy(amountInput = valid) }
    }

    fun onNoteChanged(text: String) {
        _uiState.update { it.copy(noteInput = text.take(80)) }
    }

    fun openBankSelectionSheet() {
        if (_uiState.value.isAmountValid) {
            _uiState.update { it.copy(showBankSheet = true) }
        }
    }

    fun dismissBankSelectionSheet() {
        _uiState.update { it.copy(showBankSheet = false) }
    }

    fun selectBankAccount(bankId: String) {
        _uiState.update { it.copy(selectedBankId = bankId) }
        viewModelScope.launch {
            preferencesRepository.setSelectedBankId(bankId)
        }
    }

    fun preparePinScreen() {
        _uiState.update {
            it.copy(
                showBankSheet = false,
                pinDigits = "",
                pinError = null
            )
        }
    }

    fun onPinDigitPressed(digit: String) {
        val current = _uiState.value.pinDigits
        if (current.length < 4) {
            _uiState.update {
                it.copy(
                    pinDigits = current + digit,
                    pinError = null
                )
            }
        }
    }

    fun onPinBackspace() {
        val current = _uiState.value.pinDigits
        if (current.isNotEmpty()) {
            _uiState.update {
                it.copy(
                    pinDigits = current.dropLast(1),
                    pinError = null
                )
            }
        }
    }

    fun submitPinAndProcess(onNavigateToProcessing: () -> Unit, onPaymentSuccess: () -> Unit) {
        val state = _uiState.value
        if (state.isProcessing) return
        if (state.pinDigits.length < 4) {
            _uiState.update { it.copy(pinError = "Please enter 4-digit UPI PIN") }
            return
        }

        _uiState.update {
            it.copy(
                isProcessing = true,
                processingStage = "Connecting Securely",
                paymentFailedMessage = null
            )
        }
        onNavigateToProcessing()

        paymentJob = viewModelScope.launch {
            try {
                delay(950)
                _uiState.update {
                    it.copy(processingStage = "Processing payment of ₹${state.formattedAmountDisplay}")
                }
                delay(1150)

                val now = System.currentTimeMillis()
                val record = paymentRepository.recordCompletedPayment(
                    payeeName = state.payee.name,
                    upiId = state.payee.upiId,
                    amount = state.parsedAmount,
                    bankAccount = state.selectedBank,
                    note = state.noteInput.takeIf { it.isNotBlank() },
                    timestampMillis = now
                )
                val formatter = SimpleDateFormat("dd MMMM yyyy 'at' hh:mm a", Locale.ENGLISH)
                val formattedDate = formatter.format(Date(now))
                    .replace("AM", "am")
                    .replace("PM", "pm")

                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        completedRecord = record,
                        formattedSuccessTimestamp = formattedDate
                    )
                }
                onPaymentSuccess()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        paymentFailedMessage = e.message ?: "Payment request timed out. Please retry."
                    )
                }
            }
        }
    }

    private fun computeInitials(name: String): String {
        val words = name.trim().split(Regex("\s+")).filter { it.isNotBlank() }
        return when {
            words.size >= 2 -> "${words[0].first().uppercaseChar()}${words[1].first().uppercaseChar()}"
            words.size == 1 -> words[0].take(2).uppercase()
            else -> "UP"
        }
    }
}
