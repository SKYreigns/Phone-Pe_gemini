package com.purplepay.app.data.repository

import com.purplepay.app.data.local.TransactionDao
import com.purplepay.app.data.local.TransactionEntity
import com.purplepay.app.domain.model.BankAccount
import com.purplepay.app.domain.model.BankBrandType
import com.purplepay.app.domain.model.TransactionDirection
import com.purplepay.app.domain.model.TransactionRecord
import com.purplepay.app.domain.model.TransactionStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

@Singleton
class PaymentRepository @Inject constructor(
    private val transactionDao: TransactionDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val bankAccounts = mutableListOf(
        BankAccount(
            id = "bob_1143",
            bankName = "Bank of Baroda",
            maskedNumber = "..1143",
            fullAccountNumber = "XXXX1143",
            isRecommended = true,
            balance = 42680.50,
            brandType = BankBrandType.BANK_OF_BARODA
        ),
        BankAccount(
            id = "cbi_6325",
            bankName = "Central Bank of India",
            maskedNumber = "..6325",
            fullAccountNumber = "XXXX6325",
            isRecommended = false,
            balance = 18420.00,
            brandType = BankBrandType.CENTRAL_BANK_OF_INDIA
        )
    )

    init {
        scope.launch {
            seedInitialHistoryIfEmpty()
        }
    }

    fun getBankAccounts(): List<BankAccount> = bankAccounts.toList()

    fun observeTransactions(): Flow<List<TransactionRecord>> {
        return transactionDao.observeAllTransactions().map { list ->
            list.map { it.toDomain() }
        }
    }

    suspend fun recordCompletedPayment(
        payeeName: String,
        upiId: String,
        amount: Double,
        bankAccount: BankAccount,
        note: String?,
        timestampMillis: Long = System.currentTimeMillis()
    ): TransactionRecord {
        val date = Date(timestampMillis)
        val monthFormat = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
        val timeFormat = SimpleDateFormat("dd MMM", Locale.ENGLISH)
        val txnId = "T" + SimpleDateFormat("yyMMddHHmmss", Locale.ENGLISH).format(date) +
            Random.nextInt(1000, 9999)
        val utr = (100000000000L + Random.nextLong(899999999999L)).toString()

        val record = TransactionRecord(
            transactionId = txnId,
            utrNumber = utr,
            payeeName = payeeName,
            upiId = upiId,
            amount = amount,
            direction = TransactionDirection.DEBIT,
            status = TransactionStatus.SUCCESS,
            bankName = bankAccount.bankName,
            maskedAccount = bankAccount.maskedNumber,
            note = note,
            timestampMillis = timestampMillis,
            displayTimeLabel = timeFormat.format(date),
            monthHeader = monthFormat.format(date)
        )
        val insertedId = transactionDao.insertTransaction(TransactionEntity.fromDomain(record))
        return record.copy(id = insertedId)
    }

    private suspend fun seedInitialHistoryIfEmpty() {
        if (transactionDao.getCount() > 0) return

        // Reference screenshot 87156.jpg exact history items
        val baseTime = 1795673700000L // Nov 27, 2026
        val seedItems = listOf(
            TransactionEntity(
                transactionId = "T2611261822104512",
                utrNumber = "633194827104",
                payeeName = "PINTU",
                upiId = "pintu.store@ybl",
                amount = 80.0,
                direction = TransactionDirection.DEBIT.name,
                status = TransactionStatus.SUCCESS.name,
                bankName = "Bank of Baroda",
                maskedAccount = "..1143",
                note = null,
                timestampMillis = baseTime - 86_400_000L,
                displayTimeLabel = "1 day ago",
                monthHeader = "November 2026"
            ),
            TransactionEntity(
                transactionId = "T2611261410558891",
                utrNumber = "633188412095",
                payeeName = "RAVINDRA SINGH S/O RATAN SINGH",
                upiId = "ravindrasingh@okicici",
                amount = 60.0,
                direction = TransactionDirection.CREDIT.name,
                status = TransactionStatus.SUCCESS.name,
                bankName = "Bank of Baroda",
                maskedAccount = "..1143",
                note = null,
                timestampMillis = baseTime - 90_000_000L,
                displayTimeLabel = "1 day ago",
                monthHeader = "November 2026"
            ),
            TransactionEntity(
                transactionId = "T2611241935123309",
                utrNumber = "632974512098",
                payeeName = "MR ABINASH PRADHAN",
                upiId = "abinash.p@axl",
                amount = 500.0,
                direction = TransactionDirection.DEBIT.name,
                status = TransactionStatus.SUCCESS.name,
                bankName = "Bank of Baroda",
                maskedAccount = "..1143",
                note = null,
                timestampMillis = baseTime - 3 * 86_400_000L,
                displayTimeLabel = "24 Nov",
                monthHeader = "November 2026"
            ),
            TransactionEntity(
                transactionId = "T2611211642087741",
                utrNumber = "632651092834",
                payeeName = "slice small finance bank limited",
                upiId = "slicepay@icici",
                amount = 363.0,
                direction = TransactionDirection.DEBIT.name,
                status = TransactionStatus.SUCCESS.name,
                bankName = "Bank of Baroda",
                maskedAccount = "..1143",
                note = null,
                timestampMillis = baseTime - 6 * 86_400_000L,
                displayTimeLabel = "21 Nov",
                monthHeader = "November 2026"
            ),
            TransactionEntity(
                transactionId = "T2611211120446120",
                utrNumber = "632619820471",
                payeeName = "Goibibo",
                upiId = "goibibo.payments@hdfcbank",
                amount = 49.15,
                direction = TransactionDirection.DEBIT.name,
                status = TransactionStatus.SUCCESS.name,
                bankName = "Bank of Baroda",
                maskedAccount = "..1143",
                note = null,
                timestampMillis = baseTime - 6 * 86_400_000L - 18_000_000L,
                displayTimeLabel = "21 Nov",
                monthHeader = "November 2026"
            )
        )
        transactionDao.insertAll(seedItems)
    }
}
