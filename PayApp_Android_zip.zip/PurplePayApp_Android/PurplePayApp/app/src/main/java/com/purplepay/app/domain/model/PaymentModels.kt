package com.purplepay.app.domain.model

data class BankAccount(
    val id: String,
    val bankName: String,
    val maskedNumber: String,
    val fullAccountNumber: String,
    val isRecommended: Boolean = false,
    val balance: Double = 24850.00,
    val brandType: BankBrandType
)

enum class BankBrandType {
    BANK_OF_BARODA,
    CENTRAL_BANK_OF_INDIA
}

data class PayeeInfo(
    val name: String,
    val upiId: String,
    val initials: String,
    val isDarkThemeEntry: Boolean = false
)

enum class TransactionDirection {
    DEBIT,
    CREDIT
}

enum class TransactionStatus {
    SUCCESS,
    FAILED
}

data class TransactionRecord(
    val id: Long = 0,
    val transactionId: String,
    val utrNumber: String,
    val payeeName: String,
    val upiId: String,
    val amount: Double,
    val direction: TransactionDirection,
    val status: TransactionStatus,
    val bankName: String,
    val maskedAccount: String,
    val note: String?,
    val timestampMillis: Long,
    val displayTimeLabel: String,
    val monthHeader: String
)

sealed class QrParseResult {
    data class ValidUpi(
        val payeeName: String,
        val upiId: String,
        val presetAmount: String? = null,
        val note: String? = null
    ) : QrParseResult()

    data class InvalidQr(val reason: String) : QrParseResult()
}
