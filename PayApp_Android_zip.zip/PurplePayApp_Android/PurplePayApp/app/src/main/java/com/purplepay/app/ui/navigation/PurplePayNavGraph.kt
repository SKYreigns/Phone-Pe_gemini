package com.purplepay.app.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.purplepay.app.ui.components.BottomTab
import com.purplepay.app.ui.screens.*
import com.purplepay.app.ui.viewmodel.HistoryViewModel
import com.purplepay.app.ui.viewmodel.PaymentFlowViewModel

object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val SCANNER = "scanner"
    const val ALERTS = "alerts"
    const val HISTORY = "history"
    const val AMOUNT = "amount"
    const val UPI_PIN = "upi_pin"
    const val PROCESSING = "processing"
    const val SUCCESS = "success"
}

@Composable
fun PurplePayNavGraph() {
    val navController = rememberNavController()
    val paymentViewModel: PaymentFlowViewModel = hiltViewModel()
    val historyViewModel: HistoryViewModel = hiltViewModel()

    val paymentUiState by paymentViewModel.uiState.collectAsState()
    val historyUiState by historyViewModel.uiState.collectAsState()

    val handleBottomTab: (BottomTab) -> Unit = { tab ->
        when (tab) {
            BottomTab.HOME -> navController.navigate(Routes.HOME) {
                popUpTo(Routes.HOME) { inclusive = true }
                launchSingleTop = true
            }
            BottomTab.SEARCH -> navController.navigate(Routes.SEARCH) {
                popUpTo(Routes.HOME)
                launchSingleTop = true
            }
            BottomTab.SCANNER -> navController.navigate(Routes.SCANNER) {
                launchSingleTop = true
            }
            BottomTab.ALERTS -> navController.navigate(Routes.ALERTS) {
                popUpTo(Routes.HOME)
                launchSingleTop = true
            }
            BottomTab.HISTORY -> navController.navigate(Routes.HISTORY) {
                popUpTo(Routes.HOME)
                launchSingleTop = true
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        enterTransition = { slideInHorizontally { it / 6 } + fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { slideOutHorizontally { it / 6 } + fadeOut() }
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenScanner = { navController.navigate(Routes.SCANNER) },
                onQuickPayMerchant = { name, upiId, darkTheme ->
                    paymentViewModel.startPaymentSession(
                        payeeName = name,
                        upiId = upiId,
                        darkAmountTheme = darkTheme
                    )
                    navController.navigate(Routes.AMOUNT)
                },
                onNavigateTab = handleBottomTab
            )
        }

        composable(Routes.SEARCH) {
            SearchTabScreen(
                onPayMerchant = { name, upiId ->
                    paymentViewModel.startPaymentSession(
                        payeeName = name,
                        upiId = upiId,
                        darkAmountTheme = false
                    )
                    navController.navigate(Routes.AMOUNT)
                },
                onOpenScanner = { navController.navigate(Routes.SCANNER) },
                onNavigateTab = handleBottomTab
            )
        }

        composable(Routes.ALERTS) {
            AlertsTabScreen(onNavigateTab = handleBottomTab)
        }

        composable(Routes.HISTORY) {
            HistoryScreen(
                uiState = historyUiState,
                onSearchChanged = historyViewModel::onSearchQueryChanged,
                onFilterChanged = historyViewModel::onFilterChanged,
                onSelectTransaction = historyViewModel::openTransactionDetails,
                onNavigateTab = handleBottomTab
            )
        }

        composable(Routes.SCANNER) {
            QrScannerScreen(
                onBack = { navController.popBackStack() },
                onParseQr = paymentViewModel::parseQrString,
                onValidQrDetected = { valid ->
                    paymentViewModel.startPaymentSession(
                        payeeName = valid.payeeName,
                        upiId = valid.upiId,
                        presetAmount = valid.presetAmount,
                        note = valid.note,
                        darkAmountTheme = false
                    )
                    navController.navigate(Routes.AMOUNT) {
                        popUpTo(Routes.SCANNER) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.AMOUNT) {
            PaymentAmountScreen(
                uiState = paymentUiState,
                onBack = { navController.popBackStack() },
                onToggleTheme = paymentViewModel::toggleAmountTheme,
                onAmountChanged = paymentViewModel::onAmountChanged,
                onNoteChanged = paymentViewModel::onNoteChanged,
                onProceedToPay = paymentViewModel::openBankSelectionSheet,
                onDismissBankSheet = paymentViewModel::dismissBankSelectionSheet,
                onSelectBank = paymentViewModel::selectBankAccount,
                onConfirmBankPay = {
                    paymentViewModel.preparePinScreen()
                    navController.navigate(Routes.UPI_PIN)
                }
            )
        }

        composable(Routes.UPI_PIN) {
            UpiPinScreen(
                uiState = paymentUiState,
                onDigitClick = paymentViewModel::onPinDigitPressed,
                onBackspaceClick = paymentViewModel::onPinBackspace,
                onSubmitPin = {
                    paymentViewModel.submitPinAndProcess(
                        onNavigateToProcessing = {
                            navController.navigate(Routes.PROCESSING)
                        },
                        onPaymentSuccess = {
                            navController.navigate(Routes.SUCCESS) {
                                popUpTo(Routes.HOME)
                            }
                        }
                    )
                }
            )
        }

        composable(Routes.PROCESSING) {
            PaymentProcessingScreen(
                stageText = paymentUiState.processingStage,
                failureMessage = paymentUiState.paymentFailedMessage,
                onRetry = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.SUCCESS) {
            PaymentSuccessScreen(
                uiState = paymentUiState,
                onDone = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.HOME) { inclusive = true }
                    }
                }
            )
        }
    }
}
