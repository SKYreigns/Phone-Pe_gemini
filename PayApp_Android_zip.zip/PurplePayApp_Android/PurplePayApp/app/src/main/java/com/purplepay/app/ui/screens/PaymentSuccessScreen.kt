package com.purplepay.app.ui.screens

import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplepay.app.ui.theme.*
import com.purplepay.app.ui.viewmodel.PaymentFlowUiState
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PaymentSuccessScreen(
    uiState: PaymentFlowUiState,
    onDone: () -> Unit
) {
    val context = LocalContext.current

    // State A: Full-Screen Green Checkmark + Confetti -> State B: Receipt + Promotional Carousel
    var showReceiptState by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }

    val checkScale = remember { Animatable(0.4f) }
    val checkDrawProgress = remember { Animatable(0f) }
    val confettiProgress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        checkScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(dampingRatio = 0.65f, stiffness = 360f)
        )
        checkDrawProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(420, easing = FastOutSlowInEasing)
        )
        confettiProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(700, easing = FastOutSlowInEasing)
        )
        delay(650)
        showReceiptState = true
    }

    if (!showReceiptState) {
        // STATE A: Full-Screen Green Success Animation (Video 00:12 - 00:13)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SuccessGreen),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(160.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Subtle Confetti Burst around White Circle
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val colors = listOf(
                            Color(0xFFEF4444),
                            Color(0xFF3B82F6),
                            Color(0xFFFACC15),
                            Color(0xFFFB923C),
                            Color(0xFFA855F7)
                        )
                        val angles = listOf(15.0, 48.0, 82.0, 125.0, 162.0, 205.0, 242.0, 285.0, 325.0, 348.0)
                        angles.forEachIndexed { idx, deg ->
                            val rad = Math.toRadians(deg)
                            val dist = (46.dp.toPx() + (idx % 3) * 14.dp.toPx()) * confettiProgress.value
                            val p1 = Offset(
                                c.x + (cos(rad) * dist).toFloat(),
                                c.y + (sin(rad) * dist).toFloat()
                            )
                            val p2 = Offset(
                                c.x + (cos(rad) * (dist + 8.dp.toPx())).toFloat(),
                                c.y + (sin(rad) * (dist + 6.dp.toPx())).toFloat()
                            )
                            drawLine(
                                color = colors[idx % colors.size],
                                start = p1,
                                end = p2,
                                strokeWidth = 3.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    // Large White Circular Checkmark
                    Box(
                        modifier = Modifier
                            .size(84.dp)
                            .scale(checkScale.value)
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(42.dp)) {
                            val p = Path().apply {
                                moveTo(size.width * 0.22f, size.height * 0.52f)
                                lineTo(size.width * 0.43f, size.height * 0.72f)
                                lineTo(size.width * 0.78f, size.height * 0.30f)
                            }
                            drawPath(
                                path = p,
                                color = SuccessGreen,
                                style = Stroke(
                                    width = 4.5.dp.toPx(),
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Payments Successful",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = uiState.formattedSuccessTimestamp,
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 13.5.sp
                )
            }
        }
    } else {
        // STATE B: Green Upper Header + White Rounded Receipt Card + Promotional Banner Carousel + Done Button (Video 00:14-00:15)
        Scaffold(
            containerColor = LightBackground,
            bottomBar = {
                Surface(
                    color = Color.White,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        HorizontalDivider(thickness = 1.dp, color = LightBorder)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .clickable(onClick = onDone)
                                .height(52.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Done",
                                color = PhonePePurple,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = innerPadding.calculateBottomPadding())
                    .verticalScroll(rememberScrollState())
            ) {
                // Green Upper Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SuccessGreenBanner)
                        .statusBarsPadding()
                        .padding(top = 18.dp, bottom = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.size(28.dp)) {
                                val p = Path().apply {
                                    moveTo(size.width * 0.22f, size.height * 0.52f)
                                    lineTo(size.width * 0.43f, size.height * 0.72f)
                                    lineTo(size.width * 0.78f, size.height * 0.30f)
                                }
                                drawPath(
                                    path = p,
                                    color = SuccessGreenBanner,
                                    style = Stroke(
                                        width = 3.5.dp.toPx(),
                                        cap = StrokeCap.Round,
                                        join = StrokeJoin.Round
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Payments Successful",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = uiState.formattedSuccessTimestamp,
                        color = Color.White.copy(alpha = 0.90f),
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // White Rounded Transaction Receipt Card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White,
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(AvatarBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = uiState.payee.initials,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = uiState.payee.name,
                                    color = LightTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = maskUpiId(uiState.payee.upiId),
                                    color = LightTextSecondary,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "₹${uiState.formattedAmountDisplay}",
                                        color = LightTextPrimary,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFF3F4F6)
                                    ) {
                                        Text(
                                            text = "Split Expense",
                                            color = LightTextPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(thickness = 1.dp, color = LightBorder)
                        Spacer(modifier = Modifier.height(14.dp))

                        // View Details & Share Receipt Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ReceiptActionPill(
                                label = "View Details",
                                icon = Icons.Outlined.ReceiptLong,
                                onClick = { showDetailsDialog = true }
                            )
                            ReceiptActionPill(
                                label = "Share Receipt",
                                icon = Icons.Outlined.Share,
                                onClick = {
                                    val rec = uiState.completedRecord
                                    val shareBody = buildString {
                                        appendLine("Payment Receipt - ₹${uiState.formattedAmountDisplay}")
                                        appendLine("Paid to: ${uiState.payee.name}")
                                        appendLine("UPI ID: ${uiState.payee.upiId}")
                                        appendLine("Date: ${uiState.formattedSuccessTimestamp}")
                                        if (rec != null) {
                                            appendLine("Transaction ID: ${rec.transactionId}")
                                            appendLine("UTR: ${rec.utrNumber}")
                                        }
                                    }
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, shareBody)
                                    }
                                    context.startActivity(
                                        Intent.createChooser(intent, "Share Payment Receipt")
                                    )
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Post-Payment Promotional Banner Carousel (3 Original Campaigns)
                PostPaymentPromoCarousel()

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    if (showDetailsDialog) {
        val rec = uiState.completedRecord
        AlertDialog(
            onDismissRequest = { showDetailsDialog = false },
            containerColor = Color.White,
            title = {
                Text(
                    text = "Transaction Details",
                    color = LightTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DetailLine("Transaction ID", rec?.transactionId ?: "T26112711350019")
                    DetailLine("UTR Reference", rec?.utrNumber ?: "633219481023")
                    DetailLine("Paid To", uiState.payee.name)
                    DetailLine("UPI ID", uiState.payee.upiId)
                    DetailLine("Debited From", "${uiState.selectedBank.bankName} (${uiState.selectedBank.maskedNumber})")
                    DetailLine("Amount", "₹${uiState.formattedAmountDisplay}")
                    if (!uiState.noteInput.isBlank()) {
                        DetailLine("Message", uiState.noteInput)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetailsDialog = false }) {
                    Text("Close", color = PhonePePurple, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column {
        Text(text = label, color = LightTextSecondary, fontSize = 11.5.sp)
        Text(text = value, color = LightTextPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ReceiptActionPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(PhonePePurpleTint),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = PhonePePurple,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            color = LightTextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun PostPaymentPromoCarousel() {
    val pagerState = rememberPagerState(pageCount = { 3 })

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = 14.dp),
            pageSpacing = 12.dp,
            modifier = Modifier.fillMaxWidth()
        ) { page ->
            when (page) {
                0 -> CreditScorePromoCard()
                1 -> CashbackRewardsPromoCard()
                else -> MobileRechargePromoCard()
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Page Indicators matching Video 00:14-00:15
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(3) { index ->
                val isSelected = pagerState.currentPage == index
                Box(
                    modifier = Modifier
                        .size(if (isSelected) 7.dp else 6.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) PhonePePurple else Color(0xFFC4C4CC))
                )
            }
        }
    }
}

@Composable
private fun CreditScorePromoCard() {
    Surface(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(185.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF9381FF), Color(0xFFB8B8FF), Color(0xFFC7D2FE))
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Illustration: Credit Score Gauge + Money Bag
                Box(
                    modifier = Modifier
                        .weight(0.95f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White,
                        shadowElevation = 4.dp,
                        modifier = Modifier.size(width = 132.dp, height = 108.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "CREDIT SCORE",
                                color = Color(0xFF1E3A8A),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                            Icon(
                                imageVector = Icons.Rounded.Speed,
                                contentDescription = null,
                                tint = Color(0xFF16A34A),
                                modifier = Modifier.size(38.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFDC2626))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "CHECK",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Right Promotional Typography matching Video 00:14
                Column(
                    modifier = Modifier.weight(1.05f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Know Your
Credit Score Today!",
                        color = Color(0xFF1E1B4B),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Check now for FREE.",
                        color = Color(0xFF312E81),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFF1E1B4B))
                    ) {
                        Text(
                            text = "Click Here >",
                            color = Color(0xFF1E1B4B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CashbackRewardsPromoCard() {
    Surface(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(185.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF5B21B6), Color(0xFF7C3AED))
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CardGiftcard,
                        contentDescription = null,
                        tint = Color(0xFFFDE047),
                        modifier = Modifier.size(44.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Win Up to ₹500
Assured Cashback!",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 22.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Unlock scratch cards on your next 3 UPI scans.",
                        color = Color.White.copy(alpha = 0.88f),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFFFACC15)
                    ) {
                        Text(
                            text = "Claim Rewards >",
                            color = Color(0xFF1E1B4B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MobileRechargePromoCard() {
    Surface(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(185.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF0F766E), Color(0xFF0D9488))
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Bolt,
                        contentDescription = null,
                        tint = Color(0xFFFEF08A),
                        modifier = Modifier.size(46.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Flat ₹50 Off on
Mobile Recharge!",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 22.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Instant 5G prepaid top-ups with zero platform fee.",
                        color = Color.White.copy(alpha = 0.90f),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White
                    ) {
                        Text(
                            text = "Recharge Now >",
                            color = Color(0xFF0F766E),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun maskUpiId(upiId: String): String {
    val parts = upiId.split("@")
    if (parts.size != 2) return upiId
    val prefix = parts[0]
    val maskedPrefix = if (prefix.length > 3) {
        "XXX" + prefix.drop(3)
    } else {
        "XXX$prefix"
    }
    return "$maskedPrefix@${parts[1]}"
}
