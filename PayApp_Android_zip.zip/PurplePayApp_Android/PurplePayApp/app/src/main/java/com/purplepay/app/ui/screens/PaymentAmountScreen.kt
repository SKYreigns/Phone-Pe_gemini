package com.purplepay.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.purplepay.app.domain.model.BankAccount
import com.purplepay.app.ui.components.BankLogoBadge
import com.purplepay.app.ui.components.HelpCircleButton
import com.purplepay.app.ui.components.UpiWordmarkBadge
import com.purplepay.app.ui.theme.*
import com.purplepay.app.ui.viewmodel.PaymentFlowUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentAmountScreen(
    uiState: PaymentFlowUiState,
    onBack: () -> Unit,
    onToggleTheme: () -> Unit,
    onAmountChanged: (String) -> Unit,
    onNoteChanged: (String) -> Unit,
    onProceedToPay: () -> Unit,
    onDismissBankSheet: () -> Unit,
    onSelectBank: (String) -> Unit,
    onConfirmBankPay: () -> Unit
) {
    val isDark = uiState.isDarkAmountTheme
    val bgColor = if (isDark) DarkBackground else LightBackground
    val cardBgColor = if (isDark) DarkSurface else LightSurface
    val primaryText = if (isDark) DarkTextPrimary else LightTextPrimary
    val secondaryText = if (isDark) DarkTextSecondary else LightTextSecondary
    val outlineNormal = if (isDark) DarkBorder else LightBorder
    val avatarBg = if (isDark) AvatarGold else AvatarBlue

    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Scaffold(
        containerColor = bgColor,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(56.dp)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = primaryText
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Pay",
                        color = primaryText,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Help icon (tapping also toggles Dark/Light reference theme parity)
                HelpCircleButton(
                    tint = primaryText,
                    onClick = onToggleTheme
                )
            }
        },
        bottomBar = {
            // Bottom-Anchored Full-Width Proceed to Pay Button (matches Reference 87159.jpg & video 00:00-00:02)
            val buttonBg by animateColorAsState(
                targetValue = when {
                    uiState.isAmountValid -> PhonePePurple
                    isDark -> DarkDisabledButton
                    else -> LightDisabledButton
                },
                label = "proceedBg"
            )
            val buttonText by animateColorAsState(
                targetValue = when {
                    uiState.isAmountValid -> Color.White
                    isDark -> DarkDisabledText
                    else -> LightDisabledText
                },
                label = "proceedText"
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .imePadding()
                    .navigationBarsPadding()
                    .background(buttonBg)
                    .clickable(enabled = uiState.isAmountValid) { onProceedToPay() }
                    .height(52.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Proceed to Pay",
                    color = buttonText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            // Main Payee + Amount Card matching Reference 87159.jpg & Video 00:00
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = cardBgColor,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Recipient Avatar + Name + UPI ID
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(avatarBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = uiState.payee.initials,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = uiState.payee.name,
                                color = primaryText,
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = uiState.payee.upiId,
                                color = secondaryText,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Large Purple-Bordered Amount Input Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(2.dp, PhonePePurple, RoundedCornerShape(8.dp))
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "₹",
                                color = primaryText,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                if (uiState.amountInput.isEmpty()) {
                                    Text(
                                        text = "Enter amount",
                                        color = if (isDark) Color(0xFF9E9EA6) else Color(0xFF8C8B94),
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                BasicTextField(
                                    value = uiState.amountInput,
                                    onValueChange = onAmountChanged,
                                    singleLine = true,
                                    textStyle = TextStyle(
                                        color = primaryText,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    cursorBrush = SolidColor(PhonePePurpleBright),
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Decimal,
                                        imeAction = ImeAction.Done
                                    ),
                                    keyboardActions = KeyboardActions(
                                        onDone = {
                                            if (uiState.isAmountValid) onProceedToPay()
                                        }
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .focusRequester(focusRequester)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Optional Message Input Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, outlineNormal, RoundedCornerShape(8.dp))
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (uiState.noteInput.isEmpty()) {
                            Text(
                                text = "Add a message (optional)",
                                color = if (isDark) DarkTextMuted else LightTextMuted,
                                fontSize = 14.sp
                            )
                        }
                        BasicTextField(
                            value = uiState.noteInput,
                            onValueChange = onNoteChanged,
                            singleLine = true,
                            textStyle = TextStyle(
                                color = primaryText,
                                fontSize = 14.sp
                            ),
                            cursorBrush = SolidColor(PhonePePurpleBright),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }

    // Bank Account Selection Bottom Sheet (Exact match to Reference 87162.jpg & Video 00:03-00:06)
    if (uiState.showBankSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = onDismissBankSheet,
            sheetState = sheetState,
            containerColor = LightBackground,
            dragHandle = null,
            shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
        ) {
            BankSelectionBottomSheetContent(
                amountDisplay = uiState.formattedAmountDisplay,
                accounts = uiState.bankAccounts,
                selectedBankId = uiState.selectedBankId,
                onSelectBank = onSelectBank,
                onDismiss = onDismissBankSheet,
                onPayClick = onConfirmBankPay
            )
        }
    }
}

@Composable
private fun BankSelectionBottomSheetContent(
    amountDisplay: String,
    accounts: List<BankAccount>,
    selectedBankId: String,
    onSelectBank: (String) -> Unit,
    onDismiss: () -> Unit,
    onPayClick: () -> Unit
) {
    val recommendedAccounts = accounts.filter { it.isRecommended }
    val otherAccounts = accounts.filter { !it.isRecommended }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(LightBackground)
            .navigationBarsPadding()
    ) {
        // White Header: "Total payable" on left, "₹75  X" on right
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Total payable",
                color = LightTextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "₹$amountDisplay",
                    color = LightTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(12.dp))
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Close",
                    tint = LightTextPrimary,
                    modifier = Modifier
                        .size(22.dp)
                        .clickable(onClick = onDismiss)
                )
            }
        }

        HorizontalDivider(thickness = 1.dp, color = LightBorder)

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 1: Recommended Bank Account
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Recommended",
                        color = LightTextSecondary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    recommendedAccounts.forEach { bank ->
                        BankOptionRow(
                            bank = bank,
                            amountDisplay = amountDisplay,
                            selected = bank.id == selectedBankId,
                            showAmountOnRow = true,
                            onClick = { onSelectBank(bank.id) }
                        )
                    }
                }
            }

            // Card 2: Other Bank Account
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Other bank account",
                        color = LightTextSecondary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    otherAccounts.forEach { bank ->
                        BankOptionRow(
                            bank = bank,
                            amountDisplay = amountDisplay,
                            selected = bank.id == selectedBankId,
                            showAmountOnRow = false,
                            onClick = { onSelectBank(bank.id) }
                        )
                    }
                }
            }

            // Card 3: Add Payment Methods
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Add payment methods",
                        color = LightTextSecondary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.AccountBalance,
                                contentDescription = null,
                                tint = LightTextPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Add bank accounts",
                                color = LightTextMuted,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = null,
                            tint = LightTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Primary Purple Pay CTA Button
            Button(
                onClick = onPayClick,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PhonePePurple),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(
                    text = "Pay ₹$amountDisplay",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun BankOptionRow(
    bank: BankAccount,
    amountDisplay: String,
    selected: Boolean,
    showAmountOnRow: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BankLogoBadge(brandType = bank.brandType, size = 36.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = bank.bankName,
                    color = LightTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = bank.maskedNumber,
                        color = LightTextSecondary,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    UpiWordmarkBadge()
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showAmountOnRow || selected) {
                Text(
                    text = "₹$amountDisplay",
                    color = LightTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(10.dp))
            }

            if (selected) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(SuccessGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = "Selected",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, LightTextSecondary, CircleShape)
                )
            }
        }
    }
}
