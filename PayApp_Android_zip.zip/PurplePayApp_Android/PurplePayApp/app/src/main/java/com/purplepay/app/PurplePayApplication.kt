package com.purplepay.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PurplePayApplication : Application()
